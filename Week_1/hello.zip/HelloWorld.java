public class HelloWorld {

    public static void main(String[] args) {
        // Base program thar display the prhase "Hello, World" in the terminal.
        System.out.println("Hello, World");
    }
}